# Dost: donor research and design decisions

Reviewed September 30, 2026. This is secondary research, a content audit, and a design evaluation. No donor interviews, surveys, A/B tests, or conversion measurements were conducted for Dost. Audience needs below are hypotheses to validate with actual supporters.

## Recommendation

Present Dost as an organization: lead with food assistance, medical support and education costs, then explain local coordination, annual reporting and leadership. Keep individual organizers’ personal lives and dinner preparation out of the institutional introduction. Community events and annual appeals belong further down the page. Let source-linked records and identified leadership support the organization’s credibility.

The design should make five questions easy to answer: What does Dost pay for? Who coordinates the work? What happened to last year's money? Who is responsible? How do I donate or ask a question?

## Research reviewed

| Source | Relevant evidence | Application to Dost | Limit |
| --- | --- | --- | --- |
| [NN/g: nonprofit donation usability, 2014](https://www.nngroup.com/articles/donations-nonprofit-charity-online/) | Observed users needed a clear purpose, an explanation of operations, disclosure of donation use, and an easy donation path. Plain donation labels performed more predictably than ambiguous alternatives. | Replace slogans with the funded needs and local coordination. Use “Donate.” Lead with the work and give readers access to dated financial reports. A prominent fundraising counter is optional and has been removed at the owner’s request. | Older qualitative research; it does not predict a conversion increase for Dost. |
| [NN/g: research methodology and report overview](https://www.nngroup.com/reports/attracting-donors-and-volunteers-non-profit/) | Two rounds of one-to-one usability research covered 60 nonprofit, charity, and association sites in the United States, including some smaller organizations. | Use observed donor tasks to organize the information rather than organizing around abstract brand values. | The public overview and article were reviewed; the full 222-page report was not reviewed. Most sampled organizations were larger than Dost. |
| [BBB Give.org: Donor Trust Report 2026](https://give.org/donor-trust-report/2026-trends-in-donor-trust-and-perspectives) | Among respondents who seek information before donating, charity websites were the most frequently cited influence at 54%. The study also reports a substantial gap between the importance of trust and confidence in charities. | Make the site itself useful for verification: financial summaries, dates, original sources, team, and contact. | General U.S. attitudes, not an experiment on website design or an Afghanistan-specific donor sample. |
| [BBB Give.org: privacy and security, 2025](https://give.org/news/bbb-s-give-org-study-69-worry-about-their-information-being-hacked-when-first-donating-to-a-charity) | A survey of more than 2,200 U.S. and 1,100 Canadian adults found concern about the protection and sharing of donor data. | Clearly identify Givebutter as the payment destination, avoid unnecessary data collection, and retain an understandable privacy page. | Reported concern does not establish which particular interface will improve donations. |
| [Stanford Web Credibility Project, 2002](https://credibility.stanford.edu/guidelines/index.html) | Its research synthesis emphasizes verifiable claims, visible people, usable contact information, appropriate visual design, and avoiding errors. | Link claims to sources, use existing photographs and names, maintain readable typography, and check links. | Foundational and dated; it supports principles, not a contemporary visual style. |
| [M+R Benchmarks 2026: website performance](https://mrbenchmarks.com/website-performance/) | Mobile represented 52% of participating nonprofits' traffic but 43% of donation transactions. Reported primary donation-page conversion was 11% on desktop and 8% on mobile. | Keep the mobile navigation short, preserve a visible donation link, and avoid extra steps before the existing payment service. | Benchmarks are descriptive. Dost's audience, traffic volume, and fundraising model may differ substantially. |

## Comparable organizations

These are references for information structure, not evidence that a particular design causes trust. No copy, imagery, partner badges, or ratings were borrowed.

| Organization | Observation | What is useful for Dost |
| --- | --- | --- |
| [GiveDirectly](https://www.givedirectly.org/) and its [financial explanation](https://www.givedirectly.org/financials) | The homepage immediately names the intervention. Navigation exposes evidence and finances. The financial page separates recipient support from costs. Homepage also visually inspected. | Name the actual assistance; separate money raised, costs, and family support; link to the details. Its scale and evidence base cannot be attributed to Dost. |
| [Afghans4Tomorrow](https://www.afghans4tomorrow.org/) and its [team description](https://www.afghans4tomorrow.org/about/mission-statement/) | The organization openly describes the professions and volunteer involvement of its organizers, as well as work in Afghanistan. Public text reviewed. | Professional lives and community service can sit together in the story. Its all-volunteer and financial claims do not establish the same facts for Dost. |
| [Sahar Education](https://www.sahareducation.org/) | Navigation distinguishes programs, impact reports, leadership, and giving. The footer provides organization identification and contact details. Public text reviewed; the live visual page could not be loaded. | Make reports and responsible people easy to find. Add Dost's own legal name, EIN, and public contact address when supplied. Do not borrow affiliations or endorsement marks. |

## Likely visitors and tasks to validate

1. **A first-time visitor referred by a friend:** Understand the work, see who is involved, and establish whether to donate. The homepage now answers what, where, and how before asking the visitor to read a mission statement.
2. **A previous donor:** Find the relevant year and distinguish the amount raised from the money that supported families. The annual archive preserves the year of the work separately from the publication date.
3. **An iftar guest:** Recognize the family and the event, then reach the donation campaign. Past invitations retain explicit dates and past-event labels.
4. **A donor seeking documentation:** Find a receipt contact, source report, or organization documents. Contact and reporting links remain in the main navigation and footer.

These are task hypotheses derived from Dost's sources and this conversation, not personas discovered through interviews.

## Content and design changes

| Before | After | Why |
| --- | --- | --- |
| Star ornament beside the name | Plain Dost wordmark | Removes the unwanted resemblance and avoids substituting an invented emblem. |
| Generic mission slogan | Food, healthcare and education in Afghanistan | Names the work and location. |
| Self-descriptive claims about openness and impact | Areas of support and dated distribution reports, each linked to its source | Gives the reader evidence to assess. |
| Personal fundraiser narrative | Organizational mission, approach and leadership | Supports the owner’s requested institutional tone without asserting a staffing model. |
| Repeated pale sections and equal-weight columns | A documentary image, inset introduction, dark areas-of-support section, narrative section, report cover, and dated event records | Creates hierarchy and separates different kinds of information. This is a design judgment to validate. |
| Emotional titles for archive entries | Titles naming food packages, cash assistance, medical care, and the fundraising plan | Helps returning donors identify records. |
| Prominent program categories without dates | Dated examples of past support, with the 2026 campaign distinguished from distribution reports | Avoids suggesting ongoing institutional programs or service levels beyond the evidence. |

The homepage does not republish identifiable beneficiaries' medical histories. It describes the funded needs and links to the original report for readers seeking the full account. Photographs are existing organization assets; captions do not invent dates or locations more precise than those established.

## Institutional voice

Use the organization as the subject: “Dost supports families…” and “Our published reports…”. Describe what assistance covers and where it is coordinated. Keep names and roles in Leadership. The owner has asked to remove the earlier family-dinner narrative and personal-work-schedule language from the public introduction.

A professional voice does not require a claim of worldwide reach, a full-time field team, institutional partnerships or capacity to serve millions. None of those claims is established by the available record.

## Remaining credibility work

Design cannot replace organizational documentation. The site still needs the owner's confirmed legal name, EIN, public email, any public mailing address, and the documents they want published. Team roles are retained from the original website and should be confirmed. Contact delivery is unverified. Older private annual records are still needed, and the 2026 campaign has no completed distribution report in this archive. The report summaries are not audited financial statements.

Keep original reports available. Retain the caveats: 2021 is a plan, 2025 allocations are approximate, and 2018 and 2025 reports were published the following year. Missing years should not count toward an invented cumulative total.

## Next: a practical donor usability study

Recruit 5–6 people for an initial qualitative round: two past donors, two people unfamiliar with Dost, and one or two iftar participants. Include mobile users. This has not been done, and no participants have been contacted.

Use 20-minute sessions. Ask participants to think aloud without explaining the site first:

1. After looking at the homepage briefly, describe what Dost does and where it works.
2. Find what happened to the 2025 donations. Explain the difference between money raised and family support.
3. Find the 2021 record and say whether it is a plan or a completed distribution.
4. Find who runs Dost and describe how the organization fits into their lives.
5. Find how to ask for a receipt. Do not submit personal data.
6. Start the donation journey and stop before payment. Say which service will process the gift.

Record task completion, wrong turns, misunderstood amounts, and the participant's own words. Ask what evidence is still missing before asking whether they like the design. A useful internal target is that a new visitor can explain what and where within 20 seconds, and locate the latest financial summary in under a minute. These are proposed acceptance criteria, not measured results or research-derived conversion promises.

If multiple participants misunderstand the same point, revise it and run another small round. With low traffic, direct observation will usually give more actionable feedback than trying to declare a statistically significant A/B-test winner.


## Gallery and donation-focused revision

The primary objective is to give visitors enough evidence and confidence to donate. Visual scale does not establish operational scale. The site should look established, while avoiding unverified claims about reaching millions of people, invented endorsements, or a cumulative beneficiary count assembled from incompatible annual figures.

Additional primary research reviewed:

- [NN/g, Carousels on Mobile Devices](https://www.nngroup.com/articles/mobile-carousels/): partial adjacent items signal that more content exists. Sequential navigation limits discovery; keep the collection short, provide direct access, support swipe, and keep essential information available elsewhere.
- [Baymard, Always Use Thumbnails to Represent Additional Product Images](https://baymard.com/research-articles/always-use-thumbnails-additional-images): observed ecommerce users found thumbnail previews more informative than dots. Applying that finding to a nonprofit archive is an inference, not a tested donation effect.
- [W3C WAI, Carousels Tutorial](https://www.w3.org/WAI/tutorials/carousels/): preserve keyboard operation, communicate item changes, manage focus, and let people control movement. The implementation uses manual navigation and respects reduced-motion preferences.

| Before | After | Reason |
| --- | --- | --- |
| Wide empty mat beside the selected image | Selected image in front, with the previous and next records visibly behind it | Makes the collection apparent and uses the horizontal space. |
| Different photographic colors and hard edges | Rounded frames and a light warm CSS treatment across photos and video | Visual consistency without replacing or altering the source files. |
| Caption without a date field | Year position directly below the media | Supports understanding of the archive; unknown dates remain explicitly unconfirmed. |
| A campaign total as the main financial feature | Work areas above the gallery; the latest completed distribution report in the reporting section | Centers the institution and its documented work. Current campaign amounts and supporter counts are omitted at the owner’s request. |
| Ambiguous contribution language | Clear Donate links to the existing Givebutter campaign | Keeps the donation destination easy to identify. |

The layered presentation is a visual design judgment. No research reviewed establishes that an Apple-style 3D layout or a warm hue will increase donations. Actual Dost usability sessions should check whether visitors can identify the year, distinguish fundraising from distribution, find the next item, and reach Donate without needing an explanation. Compare it with a simple image strip if the depth effect distracts from the records.


## Review: institutional presentation and trust

Additional reference pages reviewed on September 30, 2026:

- [World Food Programme](https://www.wfp.org/): mission and work, leadership, funding and accountability resources have a clear place in its information structure. Dost can use that structure without borrowing its scale, claims or visual identity.
- [UNICEF: What we do](https://www.unicef.org/what-we-do): separates focus areas from how the organization works. This is a useful editorial pattern, not evidence of a donation-conversion effect.

| Before | After | Why |
| --- | --- | --- |
| A specific annual fundraiser in the hero | Organization-level purpose: food, healthcare and education in Afghanistan | Introduces the institution and its work before its fundraising mechanism. |
| Large campaign counter | Three linked areas of support | Gives visitors a concrete understanding of what contributions support without displaying the current total. |
| Dinner preparation and the organizers’ personal schedules | About Dost, local coordination and leadership | Creates a consistent institutional voice. |
| Latest campaign as the featured report | Latest available completed distribution report, dated 2025 and published in 2026 | Leads with documented assistance while retaining the 2026 appeal in the archive. |
| Current total repeated across the header, metadata and download | No current campaign amount or supporter count in website text or portable source | Applies the owner’s request consistently. Givebutter’s external page remains separately managed. |

This is a stronger presentation, but “highest trust” is not established by desk research or visual polish. The material gaps remain public organization identification, accessible organization documents, confirmed contact delivery, confirmed media dates and missing annual records. Actual donor usability sessions are still needed to assess whether this version answers visitors’ questions.


## Grassroots identity and country coordination

The owner clarified that women’s education and basic needs are central to Dost’s mission. The hero now uses an existing photograph of an instructor with participants, and the gallery opens with the original classroom photograph. Captions describe visible teaching activities without inventing a literacy course, date or current program status.

| Before | After | Why |
| --- | --- | --- |
| Food-distribution hero | Instructor and participants from the existing teaching archive | Aligns the first impression with the owner’s stated commitment to women’s education. |
| Unnamed local coordination | Ahmad Zia Arman’s name, portrait and Country Coordinator responsibilities | Makes receipt of funds, distribution and reporting back concrete. |
| Three leadership profiles only | Three matching team cards | Gives all team members equal visual weight; country coordination is explained in How we work. |

The Country Coordinator’s responsibilities come directly from the owner. No credentials, employment status, years of service, audits or additional financial-control procedures have been invented. The current donation-allocation percentage remains pending clarification against the cost treatment in the 2025 report.


## Reports first and team correction

The owner requested earlier attention for annual reports as evidence of credibility. The reporting section now follows the hero, before areas of support and the gallery; the hero links directly to it. The latest available distribution report is clearly dated 2025, with its publication in February 2026 shown separately. Missing records and appeals remain distinguished in the archive.

Gulafroz Dailey’s public team profile was removed at the owner’s request. The visible team consists of Sara Daqiq, Shakiba Daqiq and Ahmad Zia Arman. Ahmad retains the Country Coordinator role and responsibilities supplied by the owner.


## Equal team presentation

At the owner’s request, Sara Daqiq, Ahmad Zia Arman and Shakiba Daqiq use the same card structure, portrait dimensions, name typography and role treatment. The separate coordinator feature has been removed. Ahmad’s receipt, distribution and reporting responsibilities remain in How we work.


## Clickable biographies and early report/photo access

| Before | After | Why |
| --- | --- | --- |
| Matching cards containing only names and roles | Matching cards open full biographies, with standalone page fallbacks | Preserves the requested visual consistency without losing the founders’ background. |
| Original biographies omitted during simplification | Sara’s and Shakiba’s original biographies recovered from Git, with public LinkedIn links; Ahmad’s supplied role details restored | Keeps existing context accessible and gives readers a way to explore professional background. |
| A report cover alongside a static archive list | Manual 2025/2024 report carousel with year selectors, arrows, touch swipe and mouse dragging | Supports the requested presentation while keeping every year accessible through the full archive. |
| Work categories between reports and photographs | Hero, report carousel, photograph gallery, then work and organizational details | Puts the dated record and original imagery early in the reading order. |

The 2024 report is still missing from the supplied public sources; the carousel explicitly labels it as awaiting publication. No distribution figures or outcomes have been invented. The 2025 report opens first. This hierarchy is a design judgment based on the earlier NN/g and W3C research, not a tested conversion claim. Neither carousel moves automatically.

Biography sources reviewed September 30, 2026: the original Dost website at Git commit 1be8975, [Sara’s public LinkedIn profile](https://www.linkedin.com/in/saradaqiq), and [Shakiba’s public LinkedIn profile](https://www.linkedin.com/in/shakibadaqiq). Public LinkedIn views expose only part of their employment history; the restored professional background comes primarily from the original organization biographies. Current employer, current student status, degrees not stated in the original, and new tenure calculations are not asserted.


## Year-folder media workflow and visible reporting history

| Before | After | Why |
| --- | --- | --- |
| Gallery items required manual paths and dimensions | Year folders feed an importer that resizes photographs, converts videos, generates posters and adds dates | Makes future additions practical while preserving originals and image proportions. |
| Only the featured years were immediately visible | A linked 2018–2026 timeline distinguishes reports, updates, appeals and records still to add | Makes the length of the record visible without implying missing reports have already been published. |
| Five thumbnail columns assumed a small fixed gallery | A scrolling thumbnail strip and year selector accommodate additional media | Keeps the layout usable as the archive grows. |
| Report carousel copy was hard-coded | Featured cards and timeline use the same report records, including imported report PDFs | Adding the 2024 document updates its availability everywhere. |

The importer is local and does not publish automatically. Files are grouped by the owner's year folder rather than guessed from image contents. It preserves originals, corrects photo orientation, avoids upscaling and removes EXIF metadata from optimized images. Videos retain their aspect ratio and receive a native player and poster. Source PDFs are copied unchanged. Biography dialogs and matching team cards remain in place.


## Final homepage order

At the owner’s request, the photo and video gallery now appears directly below the introduction, before the annual reports. The report timeline and carousel remain together immediately afterward, with the reporting-history link retained in the introduction and navigation.


## Recovered Facebook records and project pages

| Before | After | Why |
| --- | --- | --- |
| Hero text overlapped the instructor in the photograph | Text and the full photograph occupy separate columns, stacking below 700px | Keeps the people and teaching activity visible at every breakpoint. |
| 2021 described only a 60-family target | The May 28 completion post documents 80 families, with the May 9 appeal retained as background | Uses the later outcome while preserving the planning history. |
| 2022 was an empty archive entry | A report summarizes the April 1 field record of 110 families and the organizer’s $6,000 transfer | Turns the dated owner-supplied record into a readable report with the screenshot available to inspect. |
| 2023 had no project context | A project brief presents the dated Zeffy food-drive plan and its $107 shopping list | Documents the work without labeling its 100-household target as a completed distribution. |
| Education was described only in broad terms | An Afghan Girls Build project page links its original website and Facebook archive | Preserves a documented free web-development program and its 2017 first-session history. |

Primary records were reviewed September 30, 2026. The user supplied unmodified screenshots of Facebook posts dated June 4, 2018; May 28, 2021; and April 1, 2022. The latter two include Zia Arman’s Dari field posts. Their source images are stored in `assets/records/` and included in the report download. No direct Facebook permalinks for these personal posts were supplied.

The supplied GoFundMe URL is explicitly titled “Eid Gift 2020” and was created May 3, 2020. It cannot establish a 2024 distribution. The Zeffy parent campaign links “Project Food Drive - 2023’s Fundraiser”; the specific project page is used for the plan because the generic parent description gives different allocations. Its photos are labeled as 2022 distributions. The supplied Facebook profile is Afghan Girls Build, not the organizer’s personal timeline. Its linked original website records a free HTML/CSS/JavaScript bootcamp, first held in Kabul in winter 2017. A 2024 post or report is still needed.


### Confirmed contact address

The owner confirmed `support@dostforgood.org` and an existing catch-all on the domain. The contact page and every footer now expose this address directly. The previous Formspree destination could not be verified, so the form was removed instead of implying confirmed delivery. Contact buttons use `mailto:` and clearly state that they open the visitor’s email app. Privacy information reflects this flow. No mail routing or DNS settings were changed and no test message was sent.

| Before | After | Why |
| --- | --- | --- |
| Contact form with an unverified delivery destination | Visible support address and direct email links | Visitors know who receives their inquiry; the site uses the confirmed catch-all address. |


### 2024 owner-supplied update

The owner subsequently confirmed that the 2024 campaign was organized privately, friends and family donated directly, and funds were distributed. A retrospective yearly update now documents this account. It explicitly explains why no public annual report was published at the time and does not invent amounts, family counts, dates of distribution or supporting documents. The homepage’s 2024 carousel panel links to this update instead of a pending-record notice.


### 2026 distribution status

The owner confirmed that funds were collected during Ramadan 2026 and distribution is in progress. The annual archive and homepage timeline now label 2026 accordingly. This status update does not present distribution as complete or disclose a current fundraising total.


### Dedicated giving page

The owner supplied widget `L3xbQ8` and the account-specific Givebutter installation script. One widget is placed on a dedicated page, alongside the real food-distribution photograph, purpose of the gift, local coordination and a link to annual reporting. Donation navigation leads to this page; historical campaign sources retain their dated URLs. The external script loads only on the donation page, and the privacy text describes Givebutter’s role. A direct campaign link remains available for browsers that cannot display the widget.

| Before | After | Why |
| --- | --- | --- |
| General giving links led to the 2026 Ramadan campaign | A dedicated page for one-time and recurring support | Separates ongoing giving from a dated campaign record. |
| An external checkout had no adjacent reporting context | Original distribution photo, yearly updates and contact address beside the widget | Keeps the purpose and accountability visible while someone considers giving. |
| Duplicate widget markup supplied | One centered widget, with a flexible-height container | Avoids duplicate donation forms and lets checkout steps resize naturally. |

Installation follows the official [widget documentation](https://docs.givebutter.com/widgets/getting-started) and [embed guide](https://help.givebutter.com/en/articles/6464859-how-to-use-givebutter-widgets-on-your-website). The campaign must be published before the widget can operate. No donation is submitted during verification.
